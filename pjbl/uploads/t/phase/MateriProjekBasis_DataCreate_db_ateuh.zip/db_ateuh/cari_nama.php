<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Cari Data</title>
  </head>
  <body>
      <form class="" action="cari_nama.php" method="post">
             Nama   : <input type="text" name="nama" value="">
             <input type="submit" name="cari" value="Cari">
      </form>

      <?php
      if (isset($_POST['cari'])) {
        //bikin koneksi
        $conn = mysqli_connect("localhost","root","","db_nugas");

        //query
        $sesuatu="%" . $_POST['nama'] . "%";
        $query= mysqli_query($conn,"select * from tbl_pegawai where nama like '$sesuatu'");

        /* determine number of rows result set */
        $row_cnt = mysqli_num_rows($query);

        if ($row_cnt>0) {
          //ulangi untuk semua data
          while ($data = mysqli_fetch_object($query)) {
            //perlihatkan data
            echo "No.Induk   :" . $data->nip . "<br>";
            echo "Nama       :" . $data->nama. "<br>";
            echo "Gaji       :" . $data->gaji. "<br><br>";
          }
        } else {
          echo "<p style='color:red;'>Data tidak ada (DKMS)...</p>";
        }
      }
       ?>

  </body>
</html>
