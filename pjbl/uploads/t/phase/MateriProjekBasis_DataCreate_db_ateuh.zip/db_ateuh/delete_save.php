<?php
  //bikin koneksi
  $conn = mysqli_connect("localhost","root","","db_nugas");

  //tangkap semua var klo ditekan Submit
  if (isset($_POST['submit'])) {

    //ambil sik kabeh variabel
    $nip = $_POST['nip'];

    //query
    $query= mysqli_query($conn,"delete from tbl_pegawai where nip = '$nip'");


    //delok sik tho maz
    header("location:view3.php");
  }
?>
