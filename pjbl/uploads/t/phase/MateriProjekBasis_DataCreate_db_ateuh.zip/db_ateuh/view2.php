<?php
  //bikin koneksi
  $conn = mysqli_connect("localhost","root","","db_nugas");

  //query
  $query= mysqli_query($conn,"select * from tbl_pegawai");

  //ambil 1 data
  $data = mysqli_fetch_object($query);

  //ulangi selama datanya ada / bernilai true
  while ($data) {

      //perlihatkan data
      echo "No.Induk   :" . $data->nip . "<br>";
      echo "Gaji   :" . $data->gaji. "<br>";

      //ambil 1 data berikutnya
      $data = mysqli_fetch_object($query);
  }

 ?>
