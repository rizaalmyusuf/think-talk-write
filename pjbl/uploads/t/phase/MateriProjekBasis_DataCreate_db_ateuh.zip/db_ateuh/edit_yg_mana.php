<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Cari Data</title>
  </head>
  <body>
      <form class="" action="edit_yg_mana.php" method="post">
             NIP   : <input type="text" name="nip" value="">
             <input type="submit" name="cari" value="Cari">
      </form>

      <?php
      if (isset($_POST['cari'])) {
        //bikin koneksi
        $conn = mysqli_connect("localhost","root","","db_nugas");

        //query
        $sesuatu=$_POST['nip'];
        $query= mysqli_query($conn,"select * from tbl_pegawai where nip ='$sesuatu'");

        /* determine number of rows result set */
        $row_cnt = mysqli_num_rows($query);

        if ($row_cnt>0) {
          //ambil datanya
          $data = mysqli_fetch_object($query);

          //masukkan ke form
          echo "<hr>";
          echo "<form action='edit_save.php' method='post'>";
          echo "<br>";
          echo "<input type='hidden' name='nip' value=$data->nip>";
          echo "NAMA   <input type='text' name='nama' value=$data->nama>";
          echo "GOL   <input type='text' name='gol' value=$data->gol>";
          echo "GAJI   <input type='text' name='gaji' value=$data->gaji>";
          echo "<input type='submit' name='submit'>";
          echo "</form>";

          }
        } else {
          echo "<p style='color:red;'>Data tidak ada (DKMS)...</p>";
        }

       ?>

  </body>
</html>
