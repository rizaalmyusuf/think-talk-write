<?php
  //bikin koneksi
  $host="localhost";
  $user="root";
  $pass="";
  $db="db_nugas";
  $conn = mysqli_connect($host,$user,$pass,$db);

  //query
  $query= mysqli_query($conn,"select * from tbl_pegawai");

  //judul
  echo "No.Induk   Nama    Gol      Gaji <br>" ;
  //ulangi
  while ($data = mysqli_fetch_object($query)){

      //perlihatkan data
      echo  $data->nip . "----";
      echo  $data->nama . "----";
      echo  $data->gol. "----" ;
      echo  $data->gaji;
      echo "<a href='edit_anu_mana.php?xnip=$data->nip'> Edit </a>". "<br>";


  }

 ?>
