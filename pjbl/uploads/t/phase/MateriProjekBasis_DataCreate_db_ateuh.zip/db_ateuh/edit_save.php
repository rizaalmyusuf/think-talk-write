<?php
  //bikin koneksi
  $conn = mysqli_connect("localhost","root","","db_nugas");

  //tangkap semua var klo ditekan Submit
  if (isset($_POST['submit'])) {

    //ambil sik kabeh variabel
    $nip = $_POST['nip'];
    $nama = $_POST['nama'];
    $gol = $_POST['gol'];
    $gaji = $_POST['gaji'];

    //query
    $query= mysqli_query($conn,"update tbl_pegawai
     set nama = '$nama', gol='$gol', gaji='$gaji'
     where nip = '$nip'");


    //delok sik tho maz
    header("location:view3.php");
  }
?>
