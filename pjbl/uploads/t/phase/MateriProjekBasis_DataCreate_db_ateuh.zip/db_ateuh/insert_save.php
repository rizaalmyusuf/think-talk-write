<?php
  //bikin koneksi
  $conn = mysqli_connect("localhost","root","","db_nugas");

  //tangkap semua var klo ditekan Submit
  if (isset($_POST['submit'])) {

    //ambil sik kabeh variabel
    $nip = $_POST['nip'];
    $nama = $_POST['nama'];

    //query
    $query= mysqli_query($conn,"insert into tbl_pegawai
     (nip,nama,gaji) values ('$nip','$nama','0')");

    //delok sik tho maz
    header("location:view3.php");
  }
?>
