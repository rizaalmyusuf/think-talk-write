<?php
  //bikin koneksi
  $conn = mysqli_connect("localhost","root","","db_nugas");

  //query
  $query= mysqli_query($conn,"select * from tbl_pegawai");

  //ambil 1 data masukkan ke sebuah objek
  $data = mysqli_fetch_object($query);

  //perlihatkan data
  echo "No.Induk   :" . $data->nip . "<br>";
  echo "Nama       :" . $data->nama. "<br>";
  echo "Gaji       :" . $data->gaji. "<br>";

  //ambil 1 data masukkan ke sebuah objek
  $data = mysqli_fetch_object($query);
  
  //perlihatkan data
  echo "No.Induk   :" . $data->nip . "<br>";
  echo "Nama       :" . $data->nama. "<br>";
  echo "Gaji       :" . $data->gaji. "<br>";
 ?>
